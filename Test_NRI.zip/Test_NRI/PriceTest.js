const { chromium } = require('playwright');

(async () => {
    // Launch browser
    const browser = await chromium.launch({ headless: false });
    const context = await browser.newContext();
    const page = await context.newPage();

    // Navigate to the website
    await page.goto('https://magento.softwaretestingboard.com/');

    // Navigate to a product category page (e.g., Men's Jackets)
    await page.goto('https://magento.softwaretestingboard.com/men/tops-men/jackets-men.html'); // adjust if needed

    // Wait for page to load
    await page.waitForSelector('.products-grid');

    // Function to extract prices and convert to numbers
    async function getPrices() {
        return await page.$$eval('.price', prices => 
            prices.map(price => parseFloat(price.textContent.replace('$', '').replace(',', '')))
        );
    }

    // Verify sorting by 'Price: Highest First'
    console.log("Testing 'Price: Highest First'...");
    await page.selectOption('select[title="Sort By"]', { label: 'Price' });  // Select Price from sort dropdown
    await page.selectOption('select[title="Set Descending Direction"]', 'desc');  // Set sorting to Descending

    // Wait for sorted results to load
    await page.waitForSelector('.product-item-info');

    // Get prices after sorting by highest first
    let prices = await getPrices();
    let sortedDesc = [...prices].sort((a, b) => b - a);

    if (JSON.stringify(prices) === JSON.stringify(sortedDesc)) {
        console.log('Test Passed: Prices sorted by highest first correctly.');
    } else {
        console.log('Test Failed: Prices not sorted by highest first correctly.');
    }

    // Verify sorting by 'Price: Lowest First'
    console.log("Testing 'Price: Lowest First'...");
    await page.selectOption('select[title="Sort By"]', { label: 'Price' });  // Ensure "Price" is selected
    await page.selectOption('select[title="Set Descending Direction"]', 'asc');  // Set sorting to Ascending

    // Wait for sorted results to load
    await page.waitForSelector('.product-item-info');

    // Get prices after sorting by lowest first
    prices = await getPrices();
    let sortedAsc = [...prices].sort((a, b) => a - b);

    if (JSON.stringify(prices) === JSON.stringify(sortedAsc)) {
        console.log('Test Passed: Prices sorted by lowest first correctly.');
    } else {
        console.log('Test Failed: Prices not sorted by lowest first correctly.');
    }

    // Close browser
    await browser.close();
})();
