const { chromium } = require('playwright');

(async () => {
    // Launch browser
    const browser = await chromium.launch({ headless: false });
    const context = await browser.newContext();
    const page = await context.newPage();

    // Navigate to the website
    await page.goto('https://magento.softwaretestingboard.com/');

    // Search for 'Jacket' in the search box
    const searchBox = await page.locator('input[aria-label="Search"]');
    await searchBox.fill('Jacket');
    await searchBox.press('Enter');

    // Wait for search results to load
    await page.waitForSelector('.products-grid');

    // Get all product names from search results
    const productNames = await page.$$eval('.product-item-link', products => {
        return products.map(product => product.textContent.trim());
    });

    // Verify each product contains the word 'Jacket'
    let allProductsContainJacket = productNames.every(name => name.includes('Jacket'));

    if (allProductsContainJacket) {
        console.log('Test Passed: All search results contain the word "Jacket".');
    } else {
        console.log('Test Failed: Some search results do not contain the word "Jacket".');
    }

    // Close browser
    await browser.close();
})();
