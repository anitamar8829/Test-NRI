const { chromium } = require('playwright');

(async () => {
    // Launch browser
    const browser = await chromium.launch({ headless: false });
    const context = await browser.newContext();
    const page = await context.newPage();

    // Navigate to the website
    await page.goto('https://magento.softwaretestingboard.com/');

    // Navigate to a product page (e.g., Men's Jacket)
    await page.goto('https://magento.softwaretestingboard.com/men/tops-men/jackets-men.html'); // Adjust URL as needed

    // Select a specific product (first product in the list)
    await page.click('.product-item-info .product-item-link');

    // Wait for product page to load
    await page.waitForSelector('select[aria-label="Size"]');

    // Select size
    await page.selectOption('select[aria-label="Size"]', 'M');  // Select Medium

    // Select color (if applicable)
    const colorSelector = 'div[option-label="Color"]';
    if (await page.$(colorSelector)) {
        await page.click(`${colorSelector} .swatch-option[aria-label="Blue"]`);  // Select Blue
    }

    // Click "Add to Cart"
    await page.click('#product-addtocart-button');

    // Wait for notification to appear
    await page.waitForSelector('.message-success', { timeout: 5000 });
    const notification = await page.locator('.message-success').innerText();
    
    // Verify notification
    if (notification.includes('You added') && notification.includes('to your shopping cart')) {
        console.log('Test Passed: Add to cart notification is displayed.');
    } else {
        console.log('Test Failed: Notification not displayed.');
    }

    // Open the shopping cart
    await page.click('a.showcart');  // Click the cart icon
    await page.click('a.viewcart');  // Click "View and Edit Cart" button

    // Wait for shopping cart page to load
    await page.waitForSelector('.cart.item');

    // Verify size and color in the cart
    const cartItemSize = await page.locator('.item-options').innerText();
    
    if (cartItemSize.includes('Size: M') && cartItemSize.includes('Color: Blue')) {
        console.log('Test Passed: Correct size and color are displayed in the cart.');
    } else {
        console.log('Test Failed: Incorrect size or color displayed in the cart.');
    }

    // Update quantity
    const quantityField = page.locator('input.input-text.qty');
    await quantityField.fill('2');  // Update quantity to 2
    await page.click('button.update');  // Click update button

    // Wait for subtotal to update
    await page.waitForSelector('.cart-totals .subtotal');

    // Verify the subtotal is updated correctly
    const subtotal = await page.locator('.cart-totals .subtotal').innerText();
    console.log('Updated Subtotal:', subtotal);

    // Close browser
    await browser.close();
})();
